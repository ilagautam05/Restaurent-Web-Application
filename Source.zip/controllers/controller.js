/*
*  Responsible - Aaditya Prakash
*************************************
*   Content Description:
*   1. Forwarding the HTTP request to appropiate MongoDBService functions
*   2. Returns static pages
*************************************/

//Returns the static HTML File under public Folder
exports.display_website = function(req, res){
  // Set the response HTTP header with HTTP status and Content type
  res.writeHead(200, {'Content-Type': 'text/html'});

  //Send the response to Client with Index.html File.
  //It will automatically find and locate index.html from public or script
  res.sendFile('index.html');

};

//Creating variable of MongoDBService (Data Model)
const mongodb = require('../service/mongoDBService');


/*
*   Retrieves all the dishes from the database.
*/
exports.show_all_dishes = function(req, res){
   mongodb.ShowAllDish(req, res);
   console.log("MongoDBService : ShowAllDish()" );
};


/*
*   Retrieves all the restaurants data-items from the database.
*/
exports.show_all_resturants = function(req, res){
    mongodb.ShowAllRestaurant(req, res);
    console.log("MongoDBService : ShowAllRestaurant()" );
};

/*
*   Returns all the dishes whose name contains the given search string
*   from the Input Form of Web Application
*/
exports.show_search_dish_results = function(req, res){
    mongodb.SearchResults(req, res);
    console.log("MongoDBService : SearchResults()" );
};

/*
*   Deletes all the data of the database.
*   This would delete both the Collection namely "Menu" & "Restaurant"
*/
exports.delete_all_dishes = function(req, res){
    mongodb.DeleteAll(req, res);
    console.log("MongoDBService : DeleteAll()" );
};

/*
*    Initialize the reload of database.
*    This function will trigger the CrawlService to execute.
*    CrawlService would extract, parse & save all the data into the Database.
*/
exports.reload_all_dishes = function(req, res){
    mongodb.ReloadMenu(req, res);
    console.log("MongoDBService : ReloadMenu()" );
};

/*
*   Returns all the dishes filtered by the Restaurant Name.
*/
exports.show_all_dishes_single_restaurant = function(req , res){
    mongodb.ShowDishByResturant(req, res);
    console.log("MongoDBService : ShowDishByResturant()" );
};
