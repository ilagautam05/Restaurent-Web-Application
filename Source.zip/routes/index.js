/*
*  Responsible - Aaditya Prakash
*************************************
*   Content Description:
*   1. Defining appropriate controller functions to the supported HTTP requests
*   2. Creating of REST Based APIs.
*************************************/
'use strict';

//Using Expressing Application Object
module.exports = function(app) {

var controller = require('../controllers/controller');

/*
*   The URL for our
*/

//Display Static Website ---------------------

// Returns the static HTML File under public Folder
app.route('/')
  .get(controller.display_website);

/*
*   REST-API Interface ------------------------
*   Accept only JSON Request as parameters & retuns only JSON Response.
*/


/*
*   Retrieves all the dishes from the database.
*/
app.route('/menus')
  .get(controller.show_all_dishes);


/*
*   Returns all the dishes whose name contains the given search string
*   from the Input Form of Web Application
*/
app.route('/menus/search/')
  .post(controller.show_search_dish_results);


/*
*   Deletes all the data of the database.
*   This would delete both the Collection namely "Menu" & "Restaurant"
*/
app.route('/menus/delete')
  .get(controller.delete_all_dishes);


/*
*    Initialize the reload of database.
*    This function will trigger the CrawlService to execute.
*    CrawlService would extract, parse & save all the data into the Database.
*/
app.route('/menus/reload')
  .get(controller.reload_all_dishes);


/*
*   Returns all the dishes filtered by the Restaurant Name.
*/
app.route('/menus/restaurant')
  .post(controller.show_all_dishes_single_restaurant);


/*
*   Retrieves all the restaurants data-items from the database.
*/
app.route('/restaurants')
  .get(controller.show_all_resturants);

};
