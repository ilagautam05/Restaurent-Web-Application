/*
*  Responsible - - -
*     - Aaditya Prakash (1 PDF & 1 HTML Crawling)
*     - Ila Gautam (2 HTML Website Crawling)
*************************************
*
*   Content Description:
*   1. 3 HTML Website Crawling
*   2. 1 PDF Website Crawling
*   3. For PDF Parsing, PDF is first downloaded & stored at /cache/pdf
*       then Parse in Text file, then Again with Text File is parse for saving in Database
*   4. Cheerio and request module are used for HTML Web Crawling
*
*************************************/

//Loading of all dependent Modules
const fs        = require('fs');
const readline  = require('readline');
const request   = require('request');
const cheerio   = require('cheerio');
const PDFParser  = require('pdf2json');
const downloadPDF = require('download-pdf')

//Creating variable of MongoDBService to saving Data into Database
const mongodb = require('../service/mongoDBService');

//URL Links of the Restaurants..
const res_bpalast_url = 'https://bombay-palast.de/karte.html';
const res_bdreams_url = 'https://bombay-dreams.de/speisen.html';
const res_mpalast_pdfUrl = "https://maharadschapalast.de/maharadscha-palast.pdf";
const res_delhi6_url = "https://delhi6.de/menu-bar/";


/*
*  Responsible - Ila Gautam
*************************************
*   Content Description:
*   1. Restautant Name: Bombay Palast
*   2. Resturant HTML Crawling Function with Cheerio & Request Modules.
*   3. This Function will initiate second crawl function on completion
*************************************/

function startCrawl(req, res) {

  var restaurantName = "Bombay Palast";
  var resAddress = "Straße der Nationen 41b, 09111 Chemnitz";
  var resStAddress = "Str. der Nationen 41b"
  var resPhone = "+49(0)371/45906110";
  var resEmail = "info@bombay-palast.de";
  var imageUrl = "https://schlemmerblock.de/data/crm_vertrag/555001_170110_134946MS/logo/555001_170110_134946MS_logo_780px.jpg"
  var resHours = "Von Montag bis Sontag : 11:30 - 14:30 und 17:30 - 23:30";

  console.log("Web Crawling for Restautant : " + restaurantName + "Initiated!\n");
  console.log("Website Url: " + res_bpalast_url + "\n");

  var resDetails = {"restaurantName" : restaurantName, "address" : resAddress , "contact" : resPhone , "website" : res_bpalast_url , "email" : resEmail, "hours" : resHours, "imageUrl" : imageUrl };
  mongodb.InsertRestaurant(resDetails);

  console.log("Restautant Data Saved : \n");
  console.log("Name : " + restaurantName);
  console.log("Address : " + resAddress);
  console.log("Contact : " + resPhone);
  console.log("Website : " + res_bpalast_url);
  console.log("Email : " + resEmail + "\n");

  var json = [];

  request(res_bpalast_url, function(error, response, html){
    if(!error){
      console.log("\nLoading Website Elements\n");
      var $ = cheerio.load(html);

      var dishName= "", ingredient = "", price= "", restaurantName = "Bombay Palast";


      $('.col_1').filter(function(i, el){
        if(i<25) {
        var data = $(this);

        var content = data.text().trim();
        ingredient = data.children().slice(1).eq(0).text().trim();
        dishName = content.replace(ingredient," ");
        price = data.parent().children().last().text().trim();

        var split1 = ingredient.replace("und", ",");
        var sp = split1.replace("mit",",");
        var split2 = sp.split(" , ");

        json.push({ "dish" : dishName , "price" : price , "ingredients" : split2 , "restaurantName" : restaurantName, "imageUrl" : imageUrl, "resAddress" : resStAddress});
          console.log("\nDish : " + dishName + "\n" + "Price : " + price + "\n" + "Ingredients : " + split2);
          console.log("-------------------------------\n")
        }

      });

    }


    fs.writeFile('./cache/bpalast_Menu.json', JSON.stringify(json, null, 4), function(err){
    console.log("JSON Menu Created at /project/cache");
    });

    mongodb.InsertData(JSON.stringify(json, null, 4));
    console.log("Dished saved to Database");
    startSecondCrawl(req, res);
  });

}



/*
*  Responsible - Ila Gautam
*************************************
*   Content Description:
*   1. Restautant Name: Delhi 6 Resturant, Berlin
*   2. Resturant HTML Crawling Function with Cheerio & Request Modules.
*   3. This Function will initiate third crawl function on completion
*************************************/

function startSecondCrawl(req, res){

  var restaurantName = "Delhi 6";
  var resAddress = "Friedrichstrasse 237, 10969 Berlin";
  var resStAddress = "Friedrichstrasse 237"
  var resPhone = "030/2516775";
  var resEmail = "info@delhi6.de";
  var imageUrl = "https://delhi6.de/wp-content/themes/twentythirteen-child/images/footer-logo.png";
  var resHours = "Von Montag bis Samstag : 11:00 - 14:00 und 17:00 - 20:45\nSontag : 14:00 - 20:45";

  console.log("Web Crawling for Restautant : " + restaurantName + "Initiated!\n");
  console.log("Website Url: " + res_delhi6_url + "\n");

  var resDetails = {"restaurantName" : restaurantName, "address" : resAddress , "contact" : resPhone , "website" : res_delhi6_url , "email" : resEmail, "hours" : resHours, "imageUrl" : imageUrl };
  mongodb.InsertRestaurant(resDetails);

  console.log("Restautant Data Saved : \n");
  console.log("Name : " + restaurantName);
  console.log("Address : " + resAddress);
  console.log("Contact : " + resPhone);
  console.log("Website : " + res_bpalast_url);
  console.log("Email : " + resEmail + "\n");
  // Let's scrape Anchorman 2

  request(res_delhi6_url, function(error, response, html){
  if(!error){
   var $ = cheerio.load(html);
   console.log("\nLoading Website Elements\n");

   var dishName= "", ingredient = "", price= "", flag = 0;
   var json = [];

   $('article').filter(function(i, el){
       if(i> 16 && i<35) {
       flag = 1;
       var data = $(this);

       dishName = data.children().first().children().slice(2,3).text().trim();
       price = data.children().first().children().last().children().first().text().trim();
       ingredient = data.children().last().text().trim();

       var split1 = ingredient.replace("und", ",");
       var sp = split1.replace("mit","");
       var split2 = sp.split(", ");

          json.push({ "dish" : dishName , "price" : price , "ingredients" : split2 , "restaurantName" : restaurantName , "imageUrl" : imageUrl , "resAddress" : resStAddress});
          console.log("\nDish : " + dishName + "\n" + "Price : " + price + "\n" + "Ingredients : " + split2);
          console.log("-------------------------------\n")
         }
    });

  }

   fs.writeFile('./cache/delhi6_menu.json', JSON.stringify(json, null, 4), function(err){
   console.log("JSON Menu Created at /project/cache");

  });

   mongodb.InsertData(JSON.stringify(json, null, 4));
   console.log("Dished saved to Database");
   startThirdCrawl(req, res);

});
}

/*
*  Responsible - Aaditya Prakash
*************************************
*   Content Description:
*   1. Restautant Name: Bombay Dreams
*   2. Resturant HTML Crawling Function with Cheerio & Request Modules.
*   3. This Function will initiate 4th PDF crawl function on completion
*************************************/


function startThirdCrawl(req, res){

  var restaurantName = "Bombay Dreams";
  var resAddress = "Bornaer Str. 42, 09114 Chemnitz";
  var resStAddress = "Bornaer Straße 42"
  var resPhone = "0371/33 78 569";
  var resEmail = "info@bombay-dreams.de";
  var imageUrl = "https://nochoffen.s3.eu-central-1.amazonaws.com/poi-photos/bombay-dreams-indisches-restaurant-wittgensdorf/0c8f2499-f8dc-43c9-95c1-0638b3e6da3c.jpg";
  var resHours = "Von Montag bis Sontag : 11:30 - 14:30 und 17:30 - 22:30\nDienstag: Geschossen";

  console.log("Web Crawling for Restautant : " + restaurantName + "Initiated!\n");
  console.log("Website Url: " + res_delhi6_url + "\n");

  var resDetails = {"restaurantName" : restaurantName, "address" : resAddress , "contact" : resPhone , "website" : res_bpalast_url , "email" : resEmail, "hours" : resHours, "imageUrl" : imageUrl };
  mongodb.InsertRestaurant(resDetails);

  console.log("Restautant Data Saved : \n");
  console.log("Name : " + restaurantName);
  console.log("Address : " + resAddress);
  console.log("Contact : " + resPhone);
  console.log("Website : " + res_bpalast_url);
  console.log("Email : " + resEmail + "\n");

  request(res_bdreams_url, function(error, response, html){
    if(!error){
      var $ = cheerio.load(html);

      var dishName= "", ingredient = "", price= "";
      var json = [];

      $('.col_1').filter(function(i, el){
        if(i<25) {
        var data = $(this);

        var content = data.text().trim();
        ingredient = data.children().slice(1).eq(0).text().trim();
        dishName = content.replace(ingredient," ");
        price = data.parent().children().last().text().trim();

        var split1 = ingredient.replace("und", ",");
        var sp = split1.replace("mit",",");
        var split2 = sp.split(" , ");

        json.push({ "dish" : dishName , "price" : price , "ingredients" : split2 , "restaurantName" : restaurantName, "imageUrl" : imageUrl, "resAddress" : resStAddress});
        console.log("\nDish : " + dishName + "\n" + "Price : " + price + "\n" + "Ingredients : " + split2);
        console.log("-------------------------------\n")
        }

      })

    }

      fs.writeFile('./cache/bdreams_Menu.json', JSON.stringify(json, null, 4), function(err){
        console.log("JSON Menu Created at /project/cache");
      });

      mongodb.InsertData(JSON.stringify(json, null, 4));
      console.log("Dished saved to Database");
      startPDFCrawl(req, res);

     });



   }

 /*
 *  Responsible - Aaditya Prakash
 *************************************
 *   Content Description:
 *   1. Restautant Name: Maharadscha Palast, Chemnitz
 *   2. PDF Downloading, PDF Parsing into Text with "pdf2json" Modules, then
 *      TextParsing with "Readline" Modules.
 *   3. Download PDF & save at internal directory /cache/pdf
 *************************************/

// Downloading PDF
function startPDFCrawl(req, res) {

  var options = {
      directory: "./cache/pdf/",
      filename: "mpalast.pdf"
  }

  downloadPDF(res_mpalast_pdfUrl, options, function(err){
      if (err) throw err
      console.log("PDF Menu Download Completed")
      parsePDF(req, res);
  });
}

//Parse PDF to Text & Save at /cache/
function parsePDF(req, res) {

  let pdfParser = new PDFParser(this,1);

  pdfParser.on("pdfParser_dataError", errData => console.error(errData.parserError) );
  pdfParser.on("pdfParser_dataReady", pdfData => {

      fs.writeFile("./cache/mpalast.menu.txt", pdfParser.getRawTextContent() , () => {
      console.log('PDF Parsing Completed');
      parsePDFText(req, res);
    });
  });

  pdfParser.loadPDF("./cache/pdf/mpalast.pdf");
}

//Parse Text to Json & insert data to MongoDB
function parsePDFText(req, res){

  var restaurantName = "Maharadscha Palast";
  var resAddress = "Zschopauer Straße 48, 09111 Chemnitz";
  var resStAddress = "Zschopauer Straße 48"
  var resPhone = "0371 690 82902";
  var resEmail = "info@maharadschapalast.de";
  var imageUrl = "http://www.xpoints.de/uploads/media/default/0001/01/thumb_479_default_big.png"
  var resHours = "Von Montag bis Freitag : 16.30 – 23.30 Uhr\n Samstag, Sonn- und Feiertage: 11.30 – 14.30 Uhr und 17.30 – 24.00 Uhr";

  var resDetails = {"restaurantName" : restaurantName, "address" : resAddress , "contact" : resPhone , "website" : res_mpalast_pdfUrl , "email" : resEmail, "hours" : resHours, "imageUrl" : imageUrl };
  mongodb.InsertRestaurant(resDetails);

  console.log("Restautant Data Saved : \n");
  console.log("Name : " + restaurantName);
  console.log("Address : " + resAddress);
  console.log("Contact : " + resPhone);
  console.log("Website : " + res_bpalast_url);
  console.log("Email : " + resEmail + "\n");

  var flag  = false;
  var count = 0;

  var dishName= "", ingredient = "", price= "";
  var json = [];

  const rl = readline.createInterface({
     input: fs.createReadStream('./cache/mpalast.menu.txt'),
     crlfDelay: Infinity
  });

  rl.on('line', (line) => {
      var mLine = line;

      if(count < 25) {

      if(mLine.charAt(mLine.length -1) == "€") {
          flag = true;
          dishName = mLine.slice(2 , mLine.length -7);
          price = mLine.substr(mLine.length -7 , 7);

       } else if(mLine.charAt(0) == " " && flag == true) {

            ingredient = mLine.slice(1 , mLine.length -1);
            flag = false;

            var split1 = ingredient.replace("und", ",");
            var sp = split1.replace("mit","");
            var split2 = sp.split(", ");

            json.push({ "dish" : dishName , "price" : price , "ingredients" : split2 , "restaurantName" : restaurantName, "imageUrl" : imageUrl, "resAddress" : resStAddress});
            //console.log(dishName + "\n" + price + "\n" + ingredient);
            console.log("\nDish : " + dishName + "\n" + "Price : " + price + "\n" + "Ingredients : " + split2);
            console.log("-------------------------------\n")
            count = count+1;
          }

        }

    });

    // readline emits a close event when the file is read.
  rl.on('close', function(){
    var outputFilename = './cache/mpalast_Menu.json';

    fs.writeFile(outputFilename, JSON.stringify(json, null, 2), function(err) {
          if(err) {
            console.log(err);
          } else {
            console.log("JSON Menu Created at /project/cache");
          }
      });

      mongodb.InsertData(JSON.stringify(json, null, 4));
      console.log("Dished saved to Database");

    });

}



module.exports.startCrawl = startCrawl;
module.exports.startSecondCrawl = startSecondCrawl;
module.exports.startPDFCrawl = startPDFCrawl;
