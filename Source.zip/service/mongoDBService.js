/*
*  Responsible - Ila Gautam
*************************************
*   Content Description:
*   1. Creation of MongoDB Database
*   2. Creation of MongoDB Database Collection
*   3. Query Database : Find, Delete, InsertMany, InsertOne,
*   4. Search Database : With the use of $regex & $options
*************************************/

//Initializing the MongoDB Client
var MongoClient = require('mongodb').MongoClient;
var baseUrl = "mongodb://localhost:27017/"

// Initializing the variables
const DATABASE_NAME = "mydb";
const DISH_TABLE_NAME = "menu";
const RESTAURANT_TABLE_NAME = "restaurant";

//Creating variable of CrawlService (Processing Service )
const crawlService = require('./crawlService');

//MongoDB will create the database if it does not exist, and make a connection to it.
function CreateDB(database) {
  var url = baseUrl + database;
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    console.log("Database created!");
    db.close();
  });
}


//Function to create the collection/table
function CreateTable(database, menu) {
  var url = baseUrl + database;
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbobj = db.db(database);
    dbobj.createCollection(menu, function(err, res) {
      if (err) throw err;
      console.log("Collection: " + menu + " created!");
    db.close();
  });
 });
}

//Function to Insert Data Items into collection/table
function InsertData(myObj) {

  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    var Obj = JSON.parse(myObj);
    dbo.collection(DISH_TABLE_NAME).insertMany(Obj, function(err, res) {
      if (err) throw err;
      console.log("Number of items inserted: " + res.insertedCount);
      db.close();
    });
  });
}

//Function to Insert Data Items into collection/table
function InsertRestaurant(myObj) {

  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    dbo.collection(RESTAURANT_TABLE_NAME).insertOne(myObj, function(err, res) {
      if (err) throw err;
      console.log("Number of items inserted: " + res.insertedCount);
      db.close();
    });
  });
}

//Function to Retrieves all Items from collection "Menu"
function ShowAllDish(req, res){

  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    dbo.collection(DISH_TABLE_NAME).find({}).toArray(function(err, result) {
      if (err) throw err;
      //console.log(result);
      console.log("Search Results: " + result.length + "\n\n");
      res.set('Content-Type', 'application/json')
      res.json(result)
    db.close();
    });
  });
}

//Function to Retrieves all Items from collection "restaurant"
function ShowAllRestaurant(req, res){

  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    dbo.collection(RESTAURANT_TABLE_NAME).find({}).toArray(function(err, result) {
      if (err) throw err;
      //console.log(result);
      console.log("Search Results: " + result.length + "\n\n");
      res.set('Content-Type', 'application/json')
      res.json(result)
    db.close();
    });
  });
}

//Function to Search Items with use of $regex, $options
function SearchResults(req, res){
  var input = req.body.query;
  var category = req.body.category;
  //console.log(category);

  MongoClient.connect(baseUrl, function(err, db) {
      if (err) throw err;
      var dbo = db.db(DATABASE_NAME);
      var query = "";
      if(category == "dish")
        query = { dish : {$regex:input, $options: "$i"}};
      else
        query = { ingredients : {$regex:input , $options: "$i"} };

      dbo.collection(DISH_TABLE_NAME).find(query).toArray(function(err, result) {
        if (err) throw err;
        //console.log(result);
        console.log("Search Results: " + result.length + "\n\n");
        //res.set('Content-Type', 'application/json');
        res.json(result);
        db.close();
      });
    });

}

//Function to Delete all Items
function DeleteAll(req, res){
  var json = { "status" : "success"};

  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    dbo.collection(DISH_TABLE_NAME).drop(function(err, delOK) {
      if (err){
        console.log("Collection name: "+ DISH_TABLE_NAME +"Already deleted")
      }
      if (delOK) {
        console.log("Collection name: "+ DISH_TABLE_NAME +" deleted");
        MongoClient.connect(baseUrl, function(err, db) {
          if (err) throw err;
          var dbo = db.db(DATABASE_NAME);
          dbo.collection("restaurant").drop(function(err, delOK) {
            if (err)
              console.log("Collection name: "+ "restaurant" +"Already deleted")
            if (delOK)
              console.log("Collection name: "+ "restaurant" +" deleted")
            db.close();
          });
        });
      }
      db.close();
    });
    res.json(json);
  });
}

//Function to Delete all Items of Collection  "restaurant"
function DeleteRestaurant(){

  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    dbo.collection(RESTAURANT_TABLE_NAME).drop(function(err, delOK) {
      if (err)
        console.log("Collection name: "+ "restaurant" +"Already deleted!")
      if (delOK)
        console.log("Collection name: "+ "restaurant" +" deleted!")
      });
    db.close();
  });
}

//Function to Trigger CrawlService.
function ReloadMenu(req, res){
  var json = { "status" : "success"};
  DeleteRestaurant();
  MongoClient.connect(baseUrl, function(err, db) {
    if (err) throw err;
    var dbo = db.db(DATABASE_NAME);
    dbo.collection(DISH_TABLE_NAME).drop(function(err, delOK) {
      if (err){
        crawlService.startCrawl(req, res);
      }
      if (delOK) {
        console.log("Collection name: "+ DISH_TABLE_NAME +" deleted");
        res.json(json);
        crawlService.startCrawl(req, res);
      }
      db.close();
    });
  });
}

//Function to Retrieves dish filtered by Resturant Name
function ShowDishByResturant(req, res){
  var rName = req.body.resName;
  var query = "{}";
  if(rName != "all Restaurants")
    query = { restaurantName: rName };

  MongoClient.connect(baseUrl, function(err, db) {
  if (err) throw err;
  var dbo = db.db(DATABASE_NAME);
  dbo.collection(DISH_TABLE_NAME).find(query).toArray(function(err, result) {
    if (err) throw err;
    //console.log(result);
    console.log("Search Results: " + result.length + "\n\n");
    res.set('Content-Type', 'application/json')
    res.json(result)
    db.close();
  });
  });

}

module.exports.CreateDB = CreateDB;
module.exports.CreateTable = CreateTable;
module.exports.InsertData = InsertData;
module.exports.InsertRestaurant = InsertRestaurant;
module.exports.ShowAllDish = ShowAllDish;
module.exports.ShowAllRestaurant = ShowAllRestaurant;
module.exports.SearchResults = SearchResults;
module.exports.DeleteAll = DeleteAll;
module.exports.DeleteRestaurant = DeleteRestaurant;
module.exports.ReloadMenu = ReloadMenu;
module.exports.ShowDishByResturant = ShowDishByResturant;
