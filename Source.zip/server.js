/*
*  Responsible - Ila Gautam
*************************************
*   Content Description:
*   1. Initializing port no.
*   2. Starting Local Server at specified
*      port.
*************************************/

//Getting an express Object from App.js File
var app = require('./app');

//For common scenrios setting port to 3000
var port = 3000;

//Starting server
var server = app.listen(port, function(){
  console.log('Web Application started at port - ' + port);
});
