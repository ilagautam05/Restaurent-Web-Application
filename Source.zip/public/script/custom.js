/*
*  Responsible - Aaditya Prkash
*************************************
*   Content Description:
*   1. Defining various Event Handlers
*   2. Dynamic Generatation of layout
*   3. Sending Server Request via $.getJSON & $.ajax jQuery function
*   4. Receiving JSON Response
*************************************/

$(document).ready(function() {
  "use strict";

  //Category Section Click
  $("nav.primary ul a").click(function() {

    $(".restaurant-listing").empty();

    var selector = $(this).attr("data-filter");
    var count = 0;
    var resName = "";

    $(".display-menu-title").text('Loading...');
    $(".restaurant-listing").empty();

    $.getJSON(selector , function(data){
      $(".restaurant-listing").empty();
      $(".display-menu-title").text("Showing " + data.length + " Restaurants");

      $.each(data, function(index, value){
        displayRestaurant(value);
      });
    });
  });


  var $optionSets = $("nav.primary ul"),
  $optionLinks = $optionSets.find("a");
  $optionLinks.click(function() {
    var $this = $(this);
    // don"t proceed if already selected
    if ($this.hasClass("selected")) {
      return false;
    }
    var $optionSet = $this.parents("nav.primary ul");
    $optionSet.find(".selected").removeClass("selected");
    $this.addClass("selected");
  });


  //Search Form OnInputChange Event
  $("#menu-search:Input").on('propertychange input', function (e) {
    var valueChanged = false;

    if (e.type=='propertychange') {
        valueChanged = e.originalEvent.propertyName=='value';
    } else {
        valueChanged = true;
    }
    if (valueChanged) {

        var baseUrl = "/menus/search/";
        var radioButtonValue = $('input[name=radio]:checked').val();
        //var queryUrl = baseUrl + radioButtonValue;

        var input = $("#menu-search").val().trim();
        var data = {'query': input, 'category' : radioButtonValue};


        if(input!=null && input != " " && input != "") {

        $(".display-menu-title").text('Loading...');
        $.ajax({
          type: 'POST',
          data: JSON.stringify(data),
          contentType: 'application/json',
          url: baseUrl,
          success: function(data) {
            $(".restaurant-listing").empty();
            $(".display-menu-title").text("Showing " + data.length + " Dishes for \"" + input + "\"");
            $.each(data, function(index, value){
              displayItems(value);
            });
          }
        });
      }
    }

  });


  //Search Button Click Event
  $(".input-group-btn").click(function() {
    var baseUrl = "/menus/search/";
    var radioButtonValue = $('input[name=radio]:checked').val();
    //var queryUrl = baseUrl + radioButtonValue;

    var input = $("#menu-search").val().trim();
    var data = {'query': input, 'category' : radioButtonValue};


    if(input!=null && input != " " && input != "") {

    $(".display-menu-title").text('Loading...');
    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: baseUrl,
      success: function(data) {
        $(".restaurant-listing").empty();
        $(".display-menu-title").text("Showing " + data.length + " Dishes for \"" + input + "\"");
        $.each(data, function(index, value){
          displayItems(value);
        });
      }
    });
  }
  });


  //Browse Menu Button Click Event
  $("#btn_menus").click(function(){
    $(".display-menu-title").text('Loading...');
    $.getJSON("/menus" , function(data, status){
      if(status == "success") {
        $(".restaurant-listing").empty();
        $(".display-menu-title").text("Showing " + data.length + " Dishes from all Resturants");
        $.each(data, function(index, value){
          displayItems(value);
        });
      }
      else {
        $(".display-menu-title").text(status);
      }
    });
  });


  //Browse Restaurants Button Click Event
  $("#btn_restaurants").click(function(){
    $(".display-menu-title").text('Loading...');
    $.getJSON("/restaurants" , function(data, status){
      if(status =="success") {
        $(".restaurant-listing").empty();
        $(".display-menu-title").text("Showing " + data.length + " Resturants Available");
        $.each(data, function(index, value){
          displayRestaurant(value);
        });
      }
      else {
        $(".display-menu-title").text(status);
      }
    });
  });


  //Reload Database Button Click Event
  $("#btn_reload").click(function(){

    $(".display-menu-title").text("Database Reloaded! Click Refresh");
    $(".restaurant-listing").empty();

    $.getJSON("/menus/reload" , function(data, status){
      if(data.status == "success") {
        $(".display-menu-title").text('Database Reload! Click Refresh');
          // $.each(data, function(index, value){
          //     $(".display-menu-title").text("Showing " + data.length + " Dishes from all Resturants");
          //   displayItems(value);
          // });
        }
      else {
        $(".display-menu-title").text(status);
      }
    });
  });


  // Filter By Restaurants Section ------------------------
  $("nav.main-block ul a").click(function() {
    var selector = $(this).attr("data-filter");
    var baseUrl = "/menus/restaurant"

    var data = { "resName" : selector};

    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: baseUrl,
      success: function(data) {
        $(".restaurant-listing").empty();
        $(".display-menu-title").text("Showing " + data.length + " Dishes from " + selector);
        $.each(data, function(index, value){
          displayItems(value);
        });
      }
    });
  });


  // Custom Java Coding ---
  $.getJSON("/menus" , function(data){
    $(".display-menu-title").text("Showing " + data.length + " Dishes from all Resturants");
    $.each(data, function(index, value){
      displayItems(value);
    });
  });
  // End of main Function
});



function displayItems(item){

  $.extend({
    el: function(el, props) {
      var $el = $(document.createElement(el));
      $el.attr(props);
      return $el;
    }
  });

  // Dynamic Generation of Dish Items

  $(".restaurant-listing").append(
    $.el('div', {'class': 'col-xs-12 col-sm-12 col-md-6 col-lg-4 food-item'}).append(
      $.el('div', {'class': 'food-item-wrap'}).append(
        $.el('div', {'class': 'content'}).append(
          $.el('h5', {'class': 'title'}).append(
            $.el('a' , {'href': '#'}).text(item.dish)))
            .append( $.el('div', {'class': 'product-name'}).text(item.ingredients))
            .append( $.el('div', {'class': 'price-btn-block'}).append(
              $.el('span' , {'class': 'price'}).text(item.price))))
              //.append( $.el('a' , {'class': 'm-t-10 pull-right'}).text("Get Details")))
                .append($.el('div', {'class': 'restaurant-block'}).append(
                  $.el('div' , {'class': 'left'}).append(
                    $.el('a', {'class': 'pull-left'}).append(
                      $.el('img' , {'class': 'logo-img' , 'src' :item.imageUrl})))
                      .append( $.el('div', {'class': 'pull-left right-text'}).append(
                        $.el('a' , {'href': '#'}).text(item.restaurantName)).append(
                          $.el('span', {'class': 'restaurant-address'}).text(item.resAddress)))))));


  }

function displayRestaurant(res){

    $.extend({
      el: function(el, props) {
        var $el = $(document.createElement(el));
        $el.attr(props);
        return $el;
      }
    });

    $(".restaurant-listing").append(
      $.el('div', {'class': 'bg-gray restaurant-entry'}).append(
        $.el('div', {'class': 'row'}).append(
          $.el('div', {'class': 'col-sm-12 col-md-12 col-lg-8 text-xs-center text-sm-left'}).append(
            $.el('div', {'class': 'entry-logo'}).append(
              $.el('a', {'class': 'img-fluid'}).append(
                $.el('img' , {'class': 'restaurant-img' , 'src' :res.imageUrl}))))
                .append($.el('div', {'class': 'entry-dscr'}).append(
                  $.el('h5', {'class': 'title'}).append(
                    $.el('a' , {'href': '#'}).text(res.restaurantName)))
                    .append($.el('p' , {'class': 'simple'}).text("Address : " + res.address))
                    .append($.el('span' , {'class': 'simple'}).text("Contact : " + res.contact))
                    .append($.el('p' , {'class': 'simple'}).text("Email   : " + res.email))
                    .append($.el('span' , {'class': 'simple'}).text("Website : " + res.website))
                    .append($.el('p' , {'class': 'simple'}).text(" "))
                    .append($.el('p' , {'class': 'simple'}).text("Opening Hours :"))
                    .append($.el('p' , {'span': 'simple'}).text(res.hours))))));

                    // .append($.el('div', {'class': 'col-sm-12 col-md-12 col-lg-4 text-xs-center'}).append(
                    //   $.el('div', {'class': 'right-content bg-white'}).append(
                    //     $.el('div', {'class': 'right-review'}).append(
                    //       $.el('div', {'class': 'price-btn-block space-xs'}).append(
                    //         $.el('a' , {'class': 'btn theme-btn-dash'}).text("Update Menu")))
                    //         .append($.el('div', {'class': 'price-btn-block space-xs'}).append(
                    //           $.el('a' , {'class': 'btn theme-btn-dash'}).text("Delete Menu")))
                    //           .append($.el('div', {'class': 'price-btn-block space-xs'})
                    //           .append($.el('a' , {'class': 'btn theme-btn-dash'}).text("View Menu"))))))));

                            }
